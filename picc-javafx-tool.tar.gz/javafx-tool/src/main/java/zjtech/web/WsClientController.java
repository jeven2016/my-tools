package zjtech.web;


import javafx.event.ActionEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import zjtech.modules.common.AbstractController;


@Component
@Slf4j
@Lazy
public class WsClientController extends AbstractController {
  public void connect(ActionEvent actionEvent) {

  }

  public void send(ActionEvent actionEvent) {

  }

  public void clear(ActionEvent actionEvent) {

  }
}
