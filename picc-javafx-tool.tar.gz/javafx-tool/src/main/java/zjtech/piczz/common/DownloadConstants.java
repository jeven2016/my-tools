package zjtech.piczz.common;

public class DownloadConstants {

  public static final String SINGLE_BOOK_PARAM = "bookEntity";
  public static final String SAVE_PIC = "shouldSavePic";
  public static final String UPDATE_STATUS = "shouldUpdateStatus";
}
