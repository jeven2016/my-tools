package zjtech.piczz.common;

public class DownloadConstants {

  public static final String SINGLE_BOOK_PARAM = "bookEntity";
}
