package zjtech.modules.common;

@FunctionalInterface
public interface NoArgCallback {

  void invoke();
}
